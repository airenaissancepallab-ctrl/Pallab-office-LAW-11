
import React, { useState, useEffect } from 'react';
import { securityMonitor, formRateLimiter } from '@/lib/security';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Clock, AlertTriangle, CheckCircle } from "lucide-react";

export const SecurityDashboard = () => {
  const [events, setEvents] = useState(securityMonitor.getSecurityEvents());
  const [rateLimitStatus, setRateLimitStatus] = useState(formRateLimiter.getStatus());

  useEffect(() => {
    const interval = setInterval(() => {
      setEvents(securityMonitor.getSecurityEvents());
      setRateLimitStatus(formRateLimiter.getStatus());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (timestamp: number): string => {
    return new Date(timestamp).toLocaleTimeString();
  };

  const getEventIcon = (type: string) => {
    if (type.includes('SUSPICIOUS') || type.includes('EXCEEDED')) {
      return <AlertTriangle className="h-4 w-4 text-red-500" />;
    }
    return <CheckCircle className="h-4 w-4 text-green-500" />;
  };

  return (
    <div className="fixed bottom-4 right-4 w-96 max-h-96 overflow-hidden z-50">
      <Card className="bg-background/95 backdrop-blur border-border shadow-lg">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-emerald" />
            <CardTitle className="text-sm">Security Monitor</CardTitle>
          </div>
          <CardDescription className="text-xs">
            Real-time security status (Development Mode)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Rate Limit Status */}
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>Rate Limit:</span>
            </div>
            <span className={rateLimitStatus.isBlocked ? "text-red-500" : "text-green-500"}>
              {rateLimitStatus.attemptsRemaining} attempts left
            </span>
          </div>

          {/* Recent Events */}
          <div>
            <h4 className="text-sm font-medium mb-2">Recent Security Events</h4>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {events.slice(-5).reverse().map((event, index) => (
                <div key={index} className="flex items-center gap-2 text-xs p-2 bg-muted/50 rounded">
                  {getEventIcon(event.type)}
                  <div className="flex-1">
                    <div className="font-medium">{event.type}</div>
                    <div className="text-muted-foreground">{formatTime(event.timestamp)}</div>
                  </div>
                </div>
              ))}
              {events.length === 0 && (
                <div className="text-xs text-muted-foreground text-center py-2">
                  No security events recorded
                </div>
              )}
            </div>
          </div>

          <Button
            variant="outline"
            size="sm"
            className="w-full text-xs"
            onClick={() => {
              setEvents([]);
              console.clear();
            }}
          >
            Clear Logs
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
